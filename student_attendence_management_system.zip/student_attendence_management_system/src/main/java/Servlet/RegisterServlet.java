package Servlet;


import util.DatabaseConnection;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;

import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role"); // role can be 'user' or 'admin'

        // Hash the password (you should use a secure hashing algorithm like bcrypt)
        String hashedPassword = hashPassword(password);

        User newUser = new User();
        newUser.setUsername(username);
        newUser.setPassword(hashedPassword);
        newUser.setRole(role);

        // Create UserDAO and insert user into DB
        UserDAO userDAO = new UserDAO(Database.getConnection());
        userDAO.createUser(newUser);

        response.sendRedirect("login.jsp"); // Redirect to login page
    }

    // Helper method to hash the password
    private String hashPassword(String password) {
        // Use a secure hashing algorithm (this is just a placeholder)
        return password;  // Ideally, hash the password before saving it to DB
    }
}


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Get user from database
        UserDAO userDAO = new UserDAO(DatabaseConnection.getConnection());
        User user = userDAO.getUserByUsername(username);

        if (user != null && user.getPassword().equals(password)) {
            // Password matches, create a session
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // Redirect based on role
            if (user.getRole().equals("admin")) {
                response.sendRedirect("admin/dashboard.jsp");
            } else {
                response.sendRedirect("user/dashboard.jsp");
            }
        } else {
            // Invalid login credentials
            response.sendRedirect("login.jsp?error=Invalid credentials");
        }
    }
}

