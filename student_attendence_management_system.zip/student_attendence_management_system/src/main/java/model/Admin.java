package model;


public class Admin extends User {

}

