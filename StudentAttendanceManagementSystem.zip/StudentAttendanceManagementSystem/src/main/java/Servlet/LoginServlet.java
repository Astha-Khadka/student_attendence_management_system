package Servlet;

import jakarta.servlet.http.HttpServlet;

public class LoginServlet extends HttpServlet {
}
